
# SQL Template database deployment 

Click **Deploy to Azure**, this will load the template into azure for deployment. You will then need to populate the parameters specified in the lab guide. 
 
 The test data that will be loaded into the Db is AdventureworksLT
 
 The firewall rules for the SQL server are set to allow all azure clients to access

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FMicrosoftLearning%2FAZ-500-Azure-Security%2Fmaster%2FAllfiles%2FLabs%2FMod4_Lab02%2Fazuredeploy.json">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
