# AZ500 Mod2 Lab1 setup

Click **Deploy to Azure**
 
 
 This will deploy a new app and app service plan that can then be used to demonstrate the scale up options in AZ500 Mod2 Lab 1.

Populate the *site name, service plan name and resource group* with **unique** names.
 
<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FMicrosoftLearning%2FAZ-500-Azure-Security%2Fmaster%2FAllfiles%2FLabs%2FMod2_Lab01%2Ftemplate.json
" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
