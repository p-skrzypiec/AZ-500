# AZ500 Lab Files

This repository is a collection of setup scripts and templates for AZ500 labs. They compliment the lab exercises. 




