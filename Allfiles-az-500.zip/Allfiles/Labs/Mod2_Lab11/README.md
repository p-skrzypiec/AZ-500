# AZ500 Mod2 Lab 11 setup

Click **Deploy to Azure**
 
 
 This will deploy a new resource group with 1 Vnet 2 VMs and 3 Subnets for the AZ500 Mod 2 Lab 11.
 
**The resource group name must be Test-FW-RG**
 
<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FMicrosoftLearning%2FAZ-500-Azure-Security%2Fmaster%2FAllfiles%2FLabs%2FMod2_Lab11%2Ftemplate.json
" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
