# AZ500 Mod 2 Lab 3

This is the yaml file to support the kubernetes deployment lab 
