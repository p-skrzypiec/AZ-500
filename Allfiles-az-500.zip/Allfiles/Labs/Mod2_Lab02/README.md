# AZ500 Mod2 Lab2 setup

Click **Deploy to Azure**
 
 
 This will deploy a new blank function app.

Populate the *site name, service plan name and resource group* with **unique** names.
 
<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FMicrosoftLearning%2FAZ-500-Azure-Security%2Fmaster%2FAllfiles%2FLabs%2FMod2_Lab02%2Ftemplate.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
